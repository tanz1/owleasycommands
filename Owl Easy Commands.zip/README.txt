   ______          ___        ______           _______     __   _____ ____  __  __ __  __          _   _ _____   _____ 
  / __ \ \        / / |      |  ____|   /\    / ____\ \   / /  / ____/ __ \|  \/  |  \/  |   /\   | \ | |  __ \ / ____|
 | |  | \ \  /\  / /| |      | |__     /  \  | (___  \ \_/ /  | |   | |  | | \  / | \  / |  /  \  |  \| | |  | | (___  
 | |  | |\ \/  \/ / | |      |  __|   / /\ \  \___ \  \   /   | |   | |  | | |\/| | |\/| | / /\ \ | . ` | |  | |\___ \ 
 | |__| | \  /\  /  | |____  | |____ / ____ \ ____) |  | |    | |___| |__| | |  | | |  | |/ ____ \| |\  | |__| |____) |
  \____/   \/  \/   |______| |______/_/    \_\_____/   |_|     \_____\____/|_|  |_|_|  |_/_/    \_\_| \_|_____/|_____/ 
                                                                                                                       
                                                                                                                       
__      __      __        ___   
 \ \    / /     /_ |      / _ \  
  \ \  / /       | |     | | | | 
   \ \/ /        | |     | | | | 
    \  /     _   | |  _  | |_| | 
     \/     (_)  |_| (_)  \___/  
                                 
                                 

## OWL EASY COMMANDS
-Owl Easy Commands strives to make computer terminals such as the Windows Command Prompt to be easy to use while being intuitive.
-Version 1.0
-For Windows XP, Windows 7, Windows 10

## Installation
-Download the application from our website
-Use a file extractor program to unzip the files.
(can be found at https://www.7-zip.org/)
-Launch the .EXE

## Files List
-OwlEasyCommands.zip
>>>
-OwlEasyCommands.EXE
-ReadMe.txt

## Operating Instructions
***DO NOT CLOSE THE COMMAND PROMPT****
-Closing the Command Prompt will close the application.

## Contributing

## License
[MIT](https://choosealicense.com/licenses/mit/)